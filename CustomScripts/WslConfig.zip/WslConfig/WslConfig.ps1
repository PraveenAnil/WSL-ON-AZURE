<# 

#>

Configuration Main
{
	Param ( [string] $nodeName )


	node $nodeName
  	{
		
		Script ConfigureWSL
    	{
			GetScript = 
			{
				@{Result = "ConfigureWSL"}
			}	
		
			TestScript = 
			{
           		return $false
        	}	
		
			SetScript =
			{
				$zipDownload = "https://aka.ms/wsl-ubuntu-1604"
				$downloadedFile = "C:\Ubuntu.zip"
				$vmFolder = "C:\Users\Public\Desktop"
				Invoke-WebRequest $zipDownload -OutFile $downloadedFile -UseBasicParsing
				Add-Type -assembly "system.io.compression.filesystem"
				[io.compression.zipfile]::ExtractToDirectory($downloadedFile, $vmFolder)	
			    C:\Users\Public\Desktop\Ubuntu\Ubuntu.exe
			}
		}	
  	}
}